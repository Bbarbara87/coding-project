console.log(`Hungary-Magyarorszag`);


ul Li a{

prompt("Are you ready?");
}


   
